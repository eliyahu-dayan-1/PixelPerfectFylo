export default {
    notification
}

function notification(){
    var notifiPing = new Audio('https://res.cloudinary.com/dt3cfrjpr/video/upload/v1590757355/messenger_d1vdx5.mp3');
    notifiPing.volume = 0.15;
    notifiPing.play();
}
