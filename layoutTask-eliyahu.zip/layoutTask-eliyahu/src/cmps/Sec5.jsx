import React from 'react'

export function Sec5() {
    return (
        <section className="sec4 flex column" >
            <div className="header">
            Get early access today
            </div>
            <div className="txt">
            It only takes a minute to sign up and our free starter tier is extremely generous. If you have any questions, our support team would be happy to help you.
            </div>
            <input type="text"/>
            <button></button>
         </section>
    )
}
